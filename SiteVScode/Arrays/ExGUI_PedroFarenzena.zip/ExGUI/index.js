// let nome = prompt("Digite seu nome: ")
// let email = prompt("Digite seu email: ")

// console.log(email.trim())

// console.log(`O e-mail ${email} foi cadastrado com sucesso. Seja bem-vinda(o), ${nome}!`)

// const comidaFav = ["Lasanha", "Bife", "Guisado", "Polenta", "Massa"]
// console.log(comidaFav)

// console.log(comidaFav, "\n")

//  let comidaFavUs = prompt("Qual é a SUA comida favorita: ")
 
//  comidaFav[1] = comidaFavUs;

//  console.log(comidaFav)

// let ListaDeTarefas = []

// let tarefa1 = prompt("Digite uma tarefa")
// let tarefa2 = prompt("Digite outra tarefa")
// let tarefa3 = prompt("Digite outra De novo tarefa")


// ListaDeTarefas[0] = tarefa1
// ListaDeTarefas[1] = tarefa2
// ListaDeTarefas[2] = tarefa3

// console.log(ListaDeTarefas)

// let cumpriu = Number(prompt("Digite a terefa que você cumpriu: "))

//     if(cumpriu == 1){
//         ListaDeTarefas.splice( 0, 1)

//     } else if(cumpriu == 2){
//         ListaDeTarefas.splice( 1, 1)

//     } else if(cumpriu == 3){
//         ListaDeTarefas.splice( 2, 1)

//     }

//     console.log(ListaDeTarefas, "Essas são as terefas que faltam para você fazer")


// Aparecerá : que o array não foi delarado em fim vai dar indefinido
// let array
// console.log('a. ', array)

// // Aparecerá : null
// array = null
// console.log('b. ', array)

// // Aparecerá : 11
// array = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
// console.log('c. ', array.length)

// // Aparecerá : 3
// let i = 0
// console.log('d. ', array[i])

// // Aparecerá : (11) [3, 19, 5, 6, 7, 8, 9, 10, 11, 12, 13]
// array[i+1] = 19
// console.log('e. ', array)

// // Aparecerá :  9
// const valor = array[i+6]
// console.log('f. ', valor)



// const frase = prompt("Digite uma frase")

// console.log(frase.toUpperCase().replaceAll("A", "I"), frase.length)
// // A frase que você escrever ele vai ler ela e caso ela tiver a letra "A" irá trocar-la por I